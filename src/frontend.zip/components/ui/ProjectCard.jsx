export default function ProjectCard() {
  return <div></div>;
}
