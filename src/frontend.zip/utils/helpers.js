// Common utility functions
